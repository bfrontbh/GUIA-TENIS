/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
        
         $('#myCarousel').carousel({
            interval: 5000
        });
        
        $('.carousel .item').each(function()
        {
          var next = $(this).next();
          if (!next.length) {
            next = $(this).siblings(':first');
          }
          next.children(':first-child').clone().appendTo($(this));

          if (next.next().length>0) 
          {

              next.next().children(':first-child').clone().appendTo($(this)).addClass('rightest');

          }
          else 
          {
              $(this).siblings(':first').children(':first-child').clone().appendTo($(this));

          }
        });
        
        
    function Mudarestado(el) {
    var display = document.getElementById(el).style.display;

    if(display === "none")
        document.getElementById(el).style.display = 'block';
    else
        document.getElementById(el).style.display = 'none';
    
}
        


